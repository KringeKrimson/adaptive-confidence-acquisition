# COMP4901B: Adaptive Confidence Acquisition

This is the clean code companion to the separately submitted conference-format PDF.
It contains no API keys, raw questions/predictions, private caches, LLM weights,
fitted probe/ridge checkpoints, virtual environments or dependency source trees.
`MANIFEST.json` records every included file hash and the intentional omissions.

## Install and reproduce the principal saved results (CPU; no inference)

Use Python 3.11+ in a fresh virtual environment. From this archive's root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 OMP_NUM_THREADS=1 python -m pytest -q
python scripts/reproduce_paper.py --out outputs/paper-reproduction
```

The last command recreates all three paper figure pairs and the principal tables
from saved aggregate JSON. It copies the frozen intervals, without refitting,
bootstrap resampling, method selection or GPU calls. Inspect `tables.md` and
`provenance.json` in that output. This verifies the reported summaries, not an
independent reconstruction of paired uncertainty from per-query data.

## Build the PDF

Install a TeX distribution with pdflatex, BibTeX and standard packages, then run:

```bash
python scripts/build_paper.py --out outputs/paper-build
```

The source is `deliverables/REPORT.tex`, with the official, unchanged ACL style
used by EMNLP (acl-org/acl-style-files commit
`d5adc823ff0f80f98c80405ca0ab66c68e684409`). The builder checks for 6--8 main pages, unresolved citations and
overfull boxes. Authors: Sushobhan Rai and Noah Breidung.

## Configurations, prompts and evaluation

`configurations/original_routing.json` gives all eight original operating points,
20-seed random controls, exact model revisions, IC settings and recorded runtime;
`configurations/benefit_routing.json` gives development-selected regularization and
thresholds without fitted coefficients. `results/*protocol.json` defines costs,
matching, seeds, practical-effect rules and uncertainty. Exact QA/IC prompts live
in `src/aca/models.py` and `src/aca/ic.py` and are printed in the PDF appendix.
`confirmatory.py`, `exploratory_mixture.py`, `benefit.py` and `pregeneration.py`
contain the evaluation code; `routing.py` implements actions and cost replay.

The original confirmation is negative. The independent model-preselection result
is post-test exploratory. Both later studies are development-only; the reserved
fresh test is unused. Do not treat the unselected IC=.5 illustration as a new
confirmatory operating point.

## Optional new GPU work, not needed to reproduce saved tables

Use a supported CUDA/Linux environment and `requirements-gpu.txt`. The historical
image was Python 3.13.15, torch 2.11.0+cu128, CUDA 12.8 on Tesla T4. Requirements do
not freeze the OS/Kaggle image. Models/data are public; no HF token is needed.
This audit/package does not execute a GPU experiment.

For a Kaggle source snapshot, the generator requires a Git commit. Either use the
original repository, or initialize a local repository in the extracted archive,
add `src`, `pyproject.toml` and `kaggle/runner.py`, and commit with your own Git
identity. Then generate, without launching, a notebook for your account:

```bash
python scripts/kaggle_bundle.py --owner YOUR_KAGGLE_USERNAME --mode qwen15screen --out outputs/kaggle-bundle
```

Upload the generated `experiment.ipynb`, enable Internet and T4x2 in your own
eligible Kaggle account. Run All consumes GPU quota: this mode smoke-tests then
collects the historical development screen. The default pilot is a different,
earlier Phi pair. Keep future experiments in new outputs/protocols and never tune
on the consumed test. GitHub access does not grant private Kaggle resource access.

## Deliberate reproducibility boundary

Raw records, fresh-test manifests and fitted probe/ridge coefficients are omitted
to satisfy the course's no-data/cache/checkpoint archive requirement. Therefore
historical per-query replay needs separately controlled original caches and frozen
method artifacts, or independent reconstruction from public models/data. The
original test/benefit runners will not work without their expected frozen methods;
do not disable their hash guards or substitute the stripped configuration files.
Aggregate result fields containing per-query extension predictions/times were also
removed from archive copies; numerical summaries/intervals are unchanged.

`results/*provenance.json` maps those external records and their hashes.
No public private-cache download is configured. The independent development
runner can start from public resources without the omitted original checkpoints.
The existing presentation is not part of this code-only submission and its
proprietary authoring runtime is not required for the paper/tables.
