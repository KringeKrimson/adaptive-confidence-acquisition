"""Generate a thin, self-contained upload notebook from committed source only."""
import argparse
import base64
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile


def build(destination, owner, mode='pilot', resume_kernel=None):
    root = Path(__file__).resolve().parents[1]
    if subprocess.check_output(['git','status','--porcelain','--','src','pyproject.toml','kaggle/runner.py'],cwd=root).strip():
        raise RuntimeError('Commit inference source before building a reproducible bundle')
    files = subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as archive:
        for name in files:
            if name and (name.startswith('src/') or name in ['pyproject.toml','kaggle/runner.py'] or
                         (mode=='confirmatory' and name in ['results/qwen15_methods.json','results/confirmatory_protocol.json'])):
                content = subprocess.check_output(['git','show',f'HEAD:{name}'],cwd=root)
                archive.writestr(zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0)),content,
                                 compress_type=zipfile.ZIP_DEFLATED)
    data = buffer.getvalue()
    sha = hashlib.sha256(data).hexdigest()
    commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
    extraction = f'''import base64, hashlib, io, zipfile, pathlib
payload = base64.b64decode({base64.b64encode(data).decode()!r})
assert hashlib.sha256(payload).hexdigest() == {sha!r}
source = pathlib.Path('/kaggle/working/aca-source')
source.mkdir(exist_ok=True)
zipfile.ZipFile(io.BytesIO(payload)).extractall(source)
print('Source commit: {commit}')
'''
    installation = '''import subprocess, sys
print('Kaggle Python:', sys.version, flush=True)
subprocess.check_call([sys.executable, '-m', 'pip', 'install', '/kaggle/working/aca-source[gpu]'])
'''
    execution = f'''import os, subprocess, sys
experiment_env = dict(os.environ, ACA_MODE={mode!r}, PYTHONUNBUFFERED='1')
# A fresh process avoids notebook imports retained across dependency installation.
subprocess.check_call([sys.executable, '/kaggle/working/aca-source/kaggle/runner.py'], env=experiment_env)
'''
    if resume_kernel:
        output_name = 'research14b' if mode == 'viability14b' else mode
        execution = execution.replace('# A fresh process',
            f"experiment_env['ACA_RESUME_FROM'] = '/kaggle/input/{resume_kernel}/outputs/{output_name}'\n# A fresh process")
    qwen_small=mode in {'qwen15screen','confirmatory'}
    strong_label = '14B' if mode.endswith('14b') or qwen_small else '7B'
    pair = f'Qwen2.5-1.5B → Qwen2.5-{strong_label}' if qwen_small else f'Phi-3-mini → Qwen2.5-{strong_label}'
    cells = [dict(id='description',cell_type='markdown',metadata={},source=[
        '# Adaptive Confidence Acquisition\n',
        f'Source commit `{commit}`. Mode: **{mode}**. {pair}-Instruct. Requires GPU and Internet; no Hugging Face token or gated access.\n',
        'Save & Run All to retain per-query outputs. Experimental logic lives in Python modules.'])]
    for cell_id,code in [('extract',extraction),('install',installation),('run',execution)]:
        cells.append(dict(id=cell_id,cell_type='code',metadata={},execution_count=None,outputs=[],source=code.splitlines(True)))
    destination = Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    (destination/'experiment.ipynb').write_text(json.dumps(dict(cells=cells,nbformat=4,nbformat_minor=5,
        metadata=dict(kernelspec=dict(display_name='Python 3',language='python',name='python3'))),indent=1))
    slug = f'adaptive-confidence-acquisition-{mode}'
    metadata = dict(id=f'{owner}/{slug}',title=f'Adaptive Confidence Acquisition {mode}',
        code_file='experiment.ipynb',language='python',kernel_type='notebook',is_private=True,
        enable_gpu=True,enable_internet=True,dataset_sources=[],competition_sources=[],
        kernel_sources=[f'{owner}/{resume_kernel}'] if resume_kernel else [],model_sources=[])
    (destination/'kernel-metadata.json').write_text(json.dumps(metadata,indent=2))
    print(f'Created {destination}/experiment.ipynb; source commit {commit}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--owner',default='sushobhanrai')
    parser.add_argument('--mode',choices=['pilot','pilot14b','research','research14b','viability14b','diagnostic','qwen15screen','confirmatory'],default='pilot')
    parser.add_argument('--out',default='outputs/kaggle-bundle')
    parser.add_argument('--resume-kernel')
    args = parser.parse_args()
    build(args.out,args.owner,args.mode,args.resume_kernel)
