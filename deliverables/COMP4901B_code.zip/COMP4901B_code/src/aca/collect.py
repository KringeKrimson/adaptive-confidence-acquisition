import importlib.metadata
import platform
import time
from pathlib import Path
import torch
from . import models
from .ic import AUTHOR_COMMIT
from .metrics import exact_match, token_f1
from .storage import atomic_json, bind_manifest, fingerprint, load_records, read_json, record_path


def runtime():
    packages = {}
    for p in ['torch', 'transformers', 'datasets', 'numpy', 'accelerate',
              'bitsandbytes', 'tokenizers', 'safetensors', 'pyarrow', 'pandas']:
        try:
            packages[p] = importlib.metadata.version(p)
        except importlib.metadata.PackageNotFoundError:
            packages[p] = None
    return dict(python=platform.python_version(), packages={
        **packages},
        cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)


def source_hash():
    return fingerprint({name: Path(__file__).with_name(name).read_text()
                        for name in ['models.py', 'ic.py', 'metrics.py', 'collect.py']})


def resolve_revisions(small=models.SMALL, strong=models.STRONG):
    from huggingface_hub import HfApi, hf_hub_download, hf_hub_url, get_hf_file_metadata
    infos = {name: HfApi(token=False).model_info(name) for name in [small, strong]}
    revisions = {name: info.sha for name,info in infos.items()}
    # Test anonymous weight access, not just publicly visible model metadata.
    for name, sha in revisions.items():
        hf_hub_download(name, 'config.json', revision=sha, token=False)
        shard = next(f.rfilename for f in infos[name].siblings if f.rfilename.endswith('.safetensors'))
        get_hf_file_metadata(hf_hub_url(name,shard,revision=sha),token=False)
    return revisions


def collect(root, stages=('small', 'strong'), max_new_tokens=32, quantization='4bit-fp32',
            strong_model=models.STRONG, splits=('train', 'validation', 'test'),
            small_model=models.SMALL, answer_stop='eos'):
    root = Path(root)
    dataset = read_json(root / 'queries.json')
    if not splits or not set(splits) <= {'train', 'validation', 'test'}:
        raise ValueError('Select valid nonempty collection splits')
    all_queries = dataset['queries']
    queries = [q for q in all_queries if q['split'] in splits]
    if not queries:
        raise ValueError('No queries in selected collection splits')
    if strong_model not in models.STRONG_MODELS:
        raise ValueError('Use a supported public Qwen strong model')
    if small_model not in models.SMALL_MODELS:
        raise ValueError('Use a supported small model')
    # Author run_ic.py uses six final tokens for Qwen; 1.5B is an explicit transfer.
    last_k = 6 if small_model.startswith('Qwen/') else 3
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA GPU unavailable; select a Kaggle GPU accelerator')
    revision_path = root / 'model_revisions.json'
    if revision_path.exists():
        revisions = read_json(revision_path)
    else:
        revisions = resolve_revisions(small=small_model,strong=strong_model)
        atomic_json(revision_path, revisions)
    if set(revisions) != {small_model,strong_model}:
        raise ValueError('Model pair changed; use a different output directory')
    config = dict(schema=1, dataset_hash=fingerprint(dataset), model_revisions=revisions,
                  model_roles=dict(small=small_model,strong=strong_model),anonymous_model_access=True,
                  max_new_tokens=max_new_tokens, quantization=quantization, batch_size=1,
                  source_hash=source_hash(), runtime=runtime(), ic_author_commit=AUTHOR_COMMIT,
                  ic_last_k=last_k, ic_alpha=1.0, ic_examples=[])
    if answer_stop != 'eos' or small_model != models.SMALL:
        config.update(answer_stop=answer_stop,feature_definition='Final normalized hidden state of final ordinary QA prompt token, captured during generation prefill; no extra forward pass')
    bind_manifest(root, 'inference_manifest.json', config)
    for role, name in [('small', small_model), ('strong', strong_model)]:
        relevant = [s for s in stages if (s in {'small', 'ic'} if role == 'small' else s == 'strong')]
        missing = {s: [q for q in queries if not record_path(root, s, q).exists()] for s in relevant}
        if not any(missing.values()):
            continue
        start = time.perf_counter()
        model, tokenizer = models.load_model(name, revisions[name], quantization)
        load_seconds = time.perf_counter() - start
        torch.cuda.reset_peak_memory_stats()
        memory_before = dict(model_footprint_bytes=model.get_memory_footprint(),
                             total_bytes=torch.cuda.get_device_properties(0).total_memory,
                             visible_gpus=torch.cuda.device_count(),device='cuda:0')
        warmup = models.generate_answer(model, tokenizer, 'What is the capital of France?', 4,
                                        capture_features=role == 'small',answer_stop=answer_stop)
        if 'ic' in relevant:
            ic_warmup = models.estimate_ic(model, tokenizer, 'What is the capital of France?',last_k=last_k)
            if small_model.startswith('Qwen/'):
                check=models.verify_ic_projection(model,tokenizer,last_k)
                atomic_json(root/'overhead'/f'ic-projection-{time.time_ns()}.json',check)
        else:
            ic_warmup = None
        atomic_json(root / 'overhead' / f'{role}-{time.time_ns()}.json', dict(
            model=name, load_seconds=load_seconds, qa_warmup=warmup['elapsed_seconds'],
            ic_warmup=ic_warmup['elapsed_seconds'] if ic_warmup else 0))
        try:
            for stage in relevant:
                for i, query in enumerate(missing[stage]):
                    if stage == 'ic':
                        result = models.estimate_ic(model, tokenizer, query['question'],last_k=last_k)
                    else:
                        result = models.generate_answer(model, tokenizer, query['question'],
                                                        max_new_tokens, capture_features=stage == 'small',answer_stop=answer_stop)
                        result.update(correct=exact_match(result['prediction'], query['aliases']),
                                      f1=token_f1(result['prediction'], query['aliases']))
                    result.update(id=query['id'], split=query['split'], model=name,
                                  query_hash=fingerprint(query), config_hash=fingerprint(config))
                    atomic_json(record_path(root, stage, query), result)
                    print(f'{stage}: saved {i+1}/{len(missing[stage])} ({query["id"]})', flush=True)
        finally:
            atomic_json(root/'overhead'/f'{role}-memory-{time.time_ns()}.json',dict(
                model=name,**memory_before,peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                peak_reserved_bytes=torch.cuda.max_memory_reserved()))
            del model
            models.release_model(None)
    # Split selection schedules work; it does not change any per-query computation.
    # A later call can therefore extend this same immutable cache to held-out test.
    if all(record_path(root, s, q).exists() for s in ('small', 'strong') for q in all_queries):
        pilot_summary(root)


def pilot_summary(root):
    root = Path(root)
    queries = read_json(root / 'queries.json')['queries']
    summary, exported, by_stage = {}, [], {}
    for stage in ['small', 'strong']:
        records = load_records(root, stage, queries)
        by_stage[stage] = records
        summary[stage] = dict(model=records[0]['model'],n=len(records), accuracy=sum(r['correct'] for r in records)/len(records),
            mean_seconds=sum(r['elapsed_seconds'] for r in records)/len(records),
            total_input_tokens=sum(r['input_tokens'] for r in records),
            total_output_tokens=sum(r['output_tokens'] for r in records),
            truncated=sum(r['hit_token_limit'] for r in records))
        for q, record in zip(queries, records):
            exported.append(dict(query=q, stage=stage,
                                 **{k:v for k,v in record.items() if k != 'features'}))
    pairs = [(s['correct'],t['correct']) for s,t in zip(by_stage['small'],by_stage['strong'])]
    summary['paired'] = dict(
        both_correct=sum(s and t for s,t in pairs),
        both_wrong=sum(not s and not t for s,t in pairs),
        strong_rescues=sum(not s and t for s,t in pairs),
        strong_harms=sum(s and not t for s,t in pairs),
        strong_minus_small_accuracy=summary['strong']['accuracy']-summary['small']['accuracy'])
    atomic_json(root / 'pilot_summary.json', summary)
    atomic_json(root / 'predictions.json', exported)
    print(summary, flush=True)
    return summary
