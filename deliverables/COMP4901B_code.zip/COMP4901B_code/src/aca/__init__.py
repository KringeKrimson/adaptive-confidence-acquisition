"""Adaptive Confidence Acquisition experiments."""
